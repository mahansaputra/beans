package dev.mahansa.beans;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeansApplicationTests {

	@Test
	void contextLoads() {
	}

}
